# Security Policy

## Supported Versions
Current only the most stable release has security update support.
Meaning security patches are always patched the latest stable release. 

## Reporting a Vulnerability
Do not report potential security vulnerabilities here. Email them privately to our security team at support@axistaylor.com
